03/26/02

Test implementation for the 'C' code example in 
Application Note 187 "1-Wire Search Algorithm".

This implementation uses the low-level bit/byte/reset
API from the TMEX 1-Wire drivers to test this
search implementation.  Any other equivenent 
low-level 1-Wire drivers can be substituted. 

For other 1-Wire software see the 'Software Developer's Tools'
on iButton:  http://www.ibutton.com/
